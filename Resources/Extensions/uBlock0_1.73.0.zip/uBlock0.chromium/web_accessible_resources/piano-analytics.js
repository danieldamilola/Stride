self.pa = {
    getVisitorId() {
    },
    sendEvent() {
    },
};
